import java.io.IOException;
import java.io.PrintWriter;
import java.lang.Exception;  
import java.sql.*;
import java.text.SimpleDateFormat;  
import java.util.Date;  
import java.util.ResourceBundle;
import javax.servlet.RequestDispatcher;  
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponse;  
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class paymentServlet extends HttpServlet {  
public void doPost(HttpServletRequest request, HttpServletResponse response)  
        throws ServletException, IOException {  
		HttpSession session1 = request.getSession();
	String mtr = (String) session1.getAttribute("meternum");
		try{  
	Class.forName("com.mysql.cj.jdbc.Driver");
Connection con=DriverManager.getConnection(  
"jdbc:mysql://localhost:3306/rusitha","root","r123");  

response.setContentType("text/html");  
    PrintWriter out = response.getWriter();  
	Statement stmt=con.createStatement();   
String table = "update Registration3 set payment_status=? where meternum=?";
        PreparedStatement ps = con.prepareStatement(table);  
        ps.setString(1,"Paid");
        ps.setString(2,mtr);
		int i = ps.executeUpdate();
		  Date date = new Date();  
		  SimpleDateFormat DateFor = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
		  String stringDate= DateFor.format(date);
		  String[] parts = stringDate.split(" ");
		  System.out.println(parts[0]+" "+parts[1]);
		int amount = (int)session1.getAttribute("amount");
		String table1 = "insert into payment (meternum,date,time,amount) values(?,?,?,?)";
        PreparedStatement ps1 = con.prepareStatement(table1);  
        ps1.setString(1,mtr);
        ps1.setString(2,parts[0]);
		ps1.setString(3,parts[1]);
		ps1.setInt(4,amount);
		int j = ps1.executeUpdate();
		
		session1.setAttribute("payment","Paid");
        RequestDispatcher requestDispatcher = request.getRequestDispatcher("welcome.jsp");
 
        requestDispatcher.forward(request, response);
	con.close();  
}catch(Exception e){ System.out.println(e);}  
      
    }  
}  
          