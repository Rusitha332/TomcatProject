import org.apache.http.HttpHost; 
import elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHightLevelClient;
public class payment{
	public static void main(String[] args){
		RestHightLevelClient client = new RestHightLevelClient(RestClient.builder(new HttpHost("localhost",9200,"http")));
		
	}
}