import java.io.IOException;
import java.io.PrintWriter;
import java.lang.Exception;  
import java.sql.*;
import java.util.ResourceBundle;
import javax.servlet.RequestDispatcher;  
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponse;  
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

  //@WebServlet("/loginServlet")
public class areaServlet extends HttpServlet {  
public void doPost(HttpServletRequest request, HttpServletResponse response)  
        throws ServletException, IOException {  
  
    response.setContentType("text/html");  
    PrintWriter out = response.getWriter();  
	HttpSession session = request.getSession();  
          
    //String name=request.getParameter("adminname");  
	String userarea = request.getParameter("area");
	session.setAttribute("oldarea",userarea);
    //String pass=request.getParameter("adminpass");  
	//String temp = request.getParameter("tempinput");
	//session.setAttribute("ar",userarea);
	//String a = (String)session.getAttribute("ar");
	//System.out.println(a);

	try{  
	Class.forName("com.mysql.cj.jdbc.Driver");
Connection con=DriverManager.getConnection(  
"jdbc:mysql://localhost:3306/rusitha","root","r123");  
Statement stmt=con.createStatement();  
      //String username,userpass;
 //PreparedStatement preparedStatement = con
            //.prepareStatement("select * from Registration where area= ?") ;
            //preparedStatement.setString(1,userarea);
            

            //ResultSet rs = preparedStatement.executeQuery(); 

//while(rs.next()){
//username = rs.getString("name");
//userpass = rs.getString("password");
  //if (name.equals(username) && pass.equals(userpass)) {  
    PreparedStatement ps = con
            .prepareStatement("select * from Registration3 where area= ?") ;
            ps.setString(1,userarea);
        String Name,meter,area,mail;
		int units;
		String ph;
		ArrayList<ArrayList<String>> user = new ArrayList<ArrayList<String>>(); 

         ResultSet rs1 = ps.executeQuery();	      
         while(rs1.next()){
            //Display values
			ArrayList<String> ind = new ArrayList<String>();
            Name =  rs1.getString(1);
            ph = rs1.getString(2);
            meter =rs1.getString(3);
            area =  rs1.getString(4); 
			units = rs1.getInt("units");
			mail = rs1.getString("email");
			String payment = rs1.getString("payment_status"); 
			//String phone = Integer.toString(ph);
			String Units = Integer.toString(units);
			ind.add(Name);
			ind.add(ph);
			ind.add(meter);
			ind.add(area);
			ind.add(Units);
			ind.add(mail);
			if(payment == null) ind.add("Not Paid");
			else ind.add(payment);
			user.add(ind);
			
			
		 }rs1.close();
	 request.setAttribute("data1", user);
   RequestDispatcher rd = request.getRequestDispatcher("select.jsp");
   rd.forward(request,response); 
con.close();
          
}catch(Exception e){System.out.println(e);}     
          
    out.close();  
   }  
}  
