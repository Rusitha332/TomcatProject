import java.io.IOException;
import java.io.PrintWriter;
import java.lang.Exception;  
import java.sql.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
import javax.mail.Session;
import javax.mail.Transport;
import java.text.SimpleDateFormat;  
import java.util.Date;  
import java.util.ResourceBundle;
import javax.servlet.RequestDispatcher;  
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponse;  
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;


public class uploadServlet extends HttpServlet {  
public void doPost(HttpServletRequest request, HttpServletResponse response)  
        throws ServletException, IOException {  
  
    response.setContentType("text/html");  
    PrintWriter out = response.getWriter();  
    
	HttpSession session = request.getSession();
	
	int unitVal,amt=0;
	String units= request.getParameter("units");
	String mtr = (String) request.getParameter("mtr");
	String userarea = (String)session.getAttribute("ar");
	      
	String a = (String)session.getAttribute("ar");
	System.out.println(a);
	unitVal = Integer.parseInt(units);
	amt = unitVal*10;
	System.out.println(unitVal+" "+amt+" "+mtr); 
	Date date = new Date();
 SimpleDateFormat df = new SimpleDateFormat("HH:mm");
 String stringDate= df.format(date);
 Calendar cal = Calendar.getInstance();
 cal.setTime(date);
 cal.add(Calendar.MINUTE, 15);
 String newTime = df.format(cal.getTime());
	try{  
	Class.forName("com.mysql.cj.jdbc.Driver");
Connection con=DriverManager.getConnection(  
"jdbc:mysql://localhost:3306/rusitha","root","r123");  
Statement stmt=con.createStatement();   
String table = "update Registration3 set units=? , amount=? ,payment_status= ? ,pay_date = ? ,alert_mail = ? where meternum=?";
        PreparedStatement ps = con.prepareStatement(table);  
        ps.setInt(1,unitVal);
        ps.setInt(2,amt); 
		ps.setString(3,"Not Paid");
		ps.setString(4, newTime);
        ps.setString(5,"NotSent");
        ps.setString(6,mtr);		
        ps.executeUpdate();
		
		//PreparedStatement ps2 = con.prepareStatement("select email from Registration3 where meternum=?");  
		//ps2.setString(1,mtr);
		
		
		String recipient="";
 
      
		
		PreparedStatement ps1 = con
            .prepareStatement("select * from Registration3 where area= ?") ;
            ps1.setString(1,a);
        String Name,meter,area,mail;
		int Units;
		String ph;
		ArrayList<ArrayList<String>> user = new ArrayList<ArrayList<String>>(); 

         ResultSet rs1 = ps1.executeQuery();	      
         while(rs1.next()){
            //Display values
			ArrayList<String> ind = new ArrayList<String>();
            Name =  rs1.getString(1);
            ph = rs1.getString(2);
            meter =rs1.getString(3);
            area =  rs1.getString(4); 
			Units= rs1.getInt("units");
			mail = rs1.getString("email");
			String payment = rs1.getString("payment_status"); 
			if(meter.equals(mtr)){
				recipient= mail;
			}
			//String phone = Integer.toString(ph);
			String u = Integer.toString(Units);
			ind.add(Name);
			ind.add(ph);
			ind.add(meter);
			ind.add(area);
			ind.add(u);
			ind.add(mail);
			if(payment == null) ind.add("Not Paid");
			else ind.add(payment);
			user.add(ind);
		 }
		 rs1.close();
		 session.setAttribute("data", user);
		 System.out.println(recipient); 
	   

		RequestDispatcher requestDispatcher = request.getRequestDispatcher("Dashboard.jsp");
 
        requestDispatcher.forward(request, response);
	con.close();  
}catch(Exception e){ System.out.println(e);}  
      
    }  
}  