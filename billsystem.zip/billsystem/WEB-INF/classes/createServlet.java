import java.io.IOException;
import java.io.PrintWriter;
import java.lang.Exception;  
import java.sql.*;
import java.util.ResourceBundle;
import javax.servlet.RequestDispatcher;  
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponse;  
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;


public class createServlet extends HttpServlet {  
public void doPost(HttpServletRequest request, HttpServletResponse response)  
        throws ServletException, IOException {  
  
    response.setContentType("text/html");  
    PrintWriter out = response.getWriter();  
          
    
	HttpSession session = request.getSession();
	//ArrayList<String> details = (ArrayList<String>) request.getAttribute("ind");
	//int unitVal,amt=0;
	String username= (String)request.getParameter("username");
	String userphone = (String) request.getParameter("userphone");
    String usermeter = (String) request.getParameter("usermeter");
	String userarea = (String)session.getAttribute("ar");
	String userpass = (String) request.getParameter("userpass");
	String usermail = (String) request.getParameter("usermail");

	//int phone = Integer.parseInt(userphone);
	System.out.println(userarea);
	
	String a = (String)session.getAttribute("ar");
	System.out.println(a);


	//unitVal = Integer.parseInt(units);
	//amt = unitVal*10;
	//System.out.println(unitVal+" "+amt+" "+mtr);
	try{  
	Class.forName("com.mysql.cj.jdbc.Driver");
Connection con=DriverManager.getConnection(  
"jdbc:mysql://localhost:3306/rusitha","root","r123");  
Statement stmt=con.createStatement();   
String table = "insert into Registration3 (name,phonenum,meternum,area,password,email) values(?,?,?,?,?,?)";
        PreparedStatement ps = con.prepareStatement(table);  
        ps.setString(1,username);
        ps.setString(2,userphone); 
		ps.setString(3,usermeter);
        ps.setString(4,a);
		ps.setString(5,userpass);
		ps.setString(6,usermail);
        ps.executeUpdate();
		
		PreparedStatement ps1 = con
            .prepareStatement("select * from Registration3 where area= ?") ;
            ps1.setString(1,a);
        String Name,meter,area;
		int Units;
		String ph;
		ArrayList<ArrayList<String>> user = new ArrayList<ArrayList<String>>(); 

         ResultSet rs1 = ps1.executeQuery();	      
         while(rs1.next()){
            //Display values
			ArrayList<String> ind = new ArrayList<String>();
            Name =  rs1.getString(1);
            ph = rs1.getString(2);
            meter =rs1.getString(3);
            area =  rs1.getString(4); 
			Units= rs1.getInt("units");
			
			String payment = rs1.getString("payment_status"); 
			//String phone1 = Integer.toString(ph);
			String u = Integer.toString(Units);
			String mail = rs1.getString("email");
			ind.add(Name);
			ind.add(ph);
			ind.add(meter);
			ind.add(area);
			ind.add(u);
			ind.add(mail);
			if(payment == null) ind.add("Not Paid");
			else ind.add(payment);
			user.add(ind);
		 }
		 rs1.close();
		 session.setAttribute("data", user);

		RequestDispatcher requestDispatcher = request.getRequestDispatcher("Dashboard.jsp");
 
        requestDispatcher.forward(request, response);
	con.close();  
}catch(Exception e){ System.out.println(e);}  
      
    }  
}  