import java.io.IOException;
import java.io.PrintWriter;
import java.lang.Exception;  
import java.sql.*;
import java.util.ResourceBundle;
import javax.servlet.RequestDispatcher;  
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponse;  
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
  //@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {  
public void doPost(HttpServletRequest request, HttpServletResponse response)  
        throws ServletException, IOException {  
  
    response.setContentType("text/html");  
    PrintWriter out = response.getWriter();  
	HttpSession session1 = request.getSession();
	
          
    String name=request.getParameter("username");  
    String pass=request.getParameter("userpass");  
	try{  
	Class.forName("com.mysql.cj.jdbc.Driver");
Connection con=DriverManager.getConnection(  
"jdbc:mysql://localhost:3306/rusitha","root","r123");  
      String username,password;
//PreparedStatement ps=con.prepareStatement(  
//"select * from Registration3 where name=? and password=?");  
//ps.setString(1,name);  
//ps.setString(2,pass);  
Statement stmt=con.createStatement();  
ResultSet rs=stmt.executeQuery("select * from Registration3");  
while(rs.next()){
username = rs.getString("name");
password = rs.getString("password");

//Statement stmt=con.createStatement();  
//String QUERY = "SELECT name,phonenum,meternum,area,units,amount FROM Registration3 where name='"+name+"' ";
//ResultSet rs= ps.executeQuery(QUERY);
if((name.equals(username))&&(pass.equals(password))){
	//out.println("Welcome"+" "+username+"<br>");
	//out.println("CUSTOMER DETAILS <br>");
	//out.println("<table border=1 width=30% height=30% align=center>");  
	//out.println("<tr><th>Name</th><th>Phone number</th><th>Meter Number</th><th> Area </th><th> Units </th> <th> Amount to be paid</th><tr>");  
	
		    
	        String Name =  rs.getString("name");
            String phone = rs.getString("phonenum");
            String meter= rs.getString("meternum");
            String area =  rs.getString("area"); 
            int units = rs.getInt("units");
			int amount = rs.getInt("amount"); 
			String payment = rs.getString("payment_status");
			
			session1.setAttribute("name",Name);
			session1.setAttribute("phonenum", phone);
			session1.setAttribute("meternum", meter);
			session1.setAttribute("area", area);
			session1.setAttribute("units", units);
			session1.setAttribute("amount", amount); 
			if(payment == null) session1.setAttribute("payment","Not Paid");
			else session1.setAttribute("payment",payment);
			
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("welcome.jsp");
 
            requestDispatcher.forward(request, response);
 
			
			//out.println("<tr><td>" + Name + "</td><td>" + phone + "</td><td>" + meter + "</td><td>" + area + "</td><td>" + units + "</td><td>" + amount + "</td></tr>");   
	
	//out.println("</table>");  
    //out.println("</html></body>");  
			
    //out.println("<font color=red size=5 align=center>Confirm payment<br>");
	//out.println("<a href=welcome.jsp align=center>pay</a>");         
    //RequestDispatcher rd = request.getRequestDispatcher("userlogin.jsp");
    //rd.forward(request,response);
}
else{
  	out.println("<font color=red size=18>Login Failed!!<br>");
	out.println("<a href=index.html> Try Again!! </a>"); 
}
} rs.close();
con.close();
          
}catch(Exception e){System.out.println(e);}     
          
    out.close();  
   }  
}  