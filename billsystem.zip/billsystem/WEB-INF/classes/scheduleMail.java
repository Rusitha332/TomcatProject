import java.util.*;  
import java.lang.Exception;  
import java.sql.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
import javax.mail.Session;
import java.time.*;  
import javax.mail.Transport;
import java.text.SimpleDateFormat;  
import java.util.Date; 
public class scheduleMail implements Runnable{  
  @Override
    public void run() {  
        try{  
	Class.forName("com.mysql.cj.jdbc.Driver");
Connection con=DriverManager.getConnection(  
"jdbc:mysql://localhost:3306/rusitha","root","r123");  
Statement stmt=con.createStatement();  
      //String username,userpass,a1;

    PreparedStatement ps = con
            .prepareStatement("select * from Registration3") ;
            
        String Name,meter,area,mail,alert;
		String given_time,recipient;
		int units;
		String ph;
		//ArrayList<ArrayList<String>> user = new ArrayList<ArrayList<String>>(); 

         ResultSet rs1 = ps.executeQuery();	      
         while(rs1.next()){
            //Display values
			//ArrayList<String> ind = new ArrayList<String>();
            Name =  rs1.getString(1);
            ph = rs1.getString(2);
            meter =rs1.getString(3);
            area =  rs1.getString(4); 
			units = rs1.getInt("units");
			mail = rs1.getString("email");
			alert= rs1.getString("alert_mail");
			recipient= mail;
			given_time = rs1.getString("pay_date");
			String payment = rs1.getString("payment_status"); 
			
			//String phone = Integer.toString(ph);
			String Units = Integer.toString(units);
			//ind.add(Name);
			//ind.add(phone);
			//ind.add(meter);
			//ind.add(area);
			//ind.add(Units);
			//ind.add(mail); 
			//if(payment == null) ind.add("Not Paid");
			//else ind.add(payment);
			//user.add(ind);  
			//System.out.println(payment);
	if(payment != null){
	if(payment.equals("Not Paid") && alert.equals("NotSent")){		
	System.out.println("yes");
			LocalTime time1, time2;  
	 String[] parts1 = given_time.split(":");
	 int h1 = Integer.parseInt(parts1[0]);
	 int m1 = Integer.parseInt(parts1[1]);
	 time1 =  LocalTime.of(h1, m1);   
	 
	 Date date = new Date();
	 SimpleDateFormat df = new SimpleDateFormat("HH:mm");
	 String stringDate= df.format(date);
	 String[] parts2 = stringDate.split(":");
	 int h2 =  Integer.parseInt(parts2[0]);
	 int m2 = Integer.parseInt(parts2[1]);
	 time2 = LocalTime.of(h2, m2);  
	 
	  int returnVal = time1.compareTo(time2);  
	    if (returnVal < 0) {  
          String sender = "rusitha0303@gmail.com";
	   String password = "Rusitha@332";
 
      // using host as localhost
      String host = "smtp.gmail.com";

String port = "587";
      // Getting system properties
      Properties properties = System.getProperties();
 
      // Setting up mail server

properties.setProperty("mail.transport.protocol", "smtp");
      properties.setProperty("mail.smtp.host", host);
 properties.setProperty("mail.smtp.user",sender);
properties.setProperty("mail.smtp.password",password);
properties.setProperty("mail.smtp.port", port);
properties.setProperty("mail.smtp.auth", "true");
properties.put("mail.smtp.starttls.enable", "true");
//properties.put("mail.debug","true");
      // creating session object to get properties
      Session ses = Session.getInstance(properties, new Authenticator() {
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication(sender,password);
    }
});
ses.setDebug(true);
 
      try
      {
         // MimeMessage object.
         MimeMessage message = new MimeMessage(ses);
 
         // Set From Field: adding senders email to from field.
         message.setFrom(new InternetAddress(sender));
 
         // Set To Field: adding recipient's email to from field.
         message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
 
         // Set Subject: subject of the email
         message.setSubject("EB Bill Alert!!!");
 
         // set body of the email.
         message.setText("Your billing deathline crossed.Kindly pay your EB Bill by today");
 
         // Send email.
 Transport transport = ses.getTransport("smtp");

    transport.connect(sender, password);
         transport.send(message);
		 String q = "update Registration3 set alert_mail= ? where meternum= ?";
         PreparedStatement ps1 = con.prepareStatement(q);
		 ps1.setString(1,"Sent");
		 ps1.setString(2,meter);
		 ps1.executeUpdate();
         System.out.println("Mail successfully sent");
transport.close();
      }
      catch (MessagingException mex)
      {
         mex.printStackTrace();
      }
		}
	}
	}
			
		 }rs1.close();
con.close();
          
}catch(Exception e){System.out.println(e);}     
     
    };  

   }  
